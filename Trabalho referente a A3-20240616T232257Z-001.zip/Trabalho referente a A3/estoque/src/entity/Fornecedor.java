package entity;

public class Fornecedor {

    private int idFornec;
    private String nomeFornec;

    public int getIdFornec() {
        return idFornec;
    }

    public void setIdFornec(int idFornec) {
        this.idFornec = idFornec;
    }

    public String getNomeFornec() {
        return nomeFornec;
    }

    public void setNomeFornec(String nomeFornec) {
        this.nomeFornec = nomeFornec;
    }
}
package entity;

public class Cliente {

    private int idCli;
    private String nomeCli;
 
    public int getIdCli() {
        return idCli;
    }
    public void setIdCli(int idCli) {
        this.idCli = idCli;
    }

    public String getNomeCli() {
        return nomeCli;
    }
    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }
    public void setText(String nomeCli2) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setText'");
    }
    
}

